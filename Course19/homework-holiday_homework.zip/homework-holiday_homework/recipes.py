# Create a recipe class with ingredients and a put them in a recipe manager program 
# that organizes them into categories like deserts, main courses 
# or by ingredients like chicken, beef, soups, pies etc.


