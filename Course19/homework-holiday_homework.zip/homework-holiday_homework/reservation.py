# Create a reservation system which books airline seats and hotel rooms. 
# It charges various rates for particular sections of the plane or hotel. 
# Example, first class is going to cost more than coach. 
# Hotel rooms have penthouse suites which cost more. 
# Keep track of when rooms/seats will be available and can be scheduled (save them in a file)
# Create commands which can be given through the terminal (use sys.argv to read the params)
# Make unit tests for functions

