# Create a flower shop application which deals in flower objects 
# and use those flower objects in a bouquet object which can then be sold. 
# Keep track of the number of objects and when you may need to order more (keep them in a file) 
# Allow the user to give commands through the terminal (use sys.argv to read the commands)
# Make unit tests

