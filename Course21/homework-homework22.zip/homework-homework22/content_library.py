# Create an app to keep track of the entertainment/content you consume
# We should be able to create multiple profiles(users) 
# Each user can track the progress of games, films, tv shows & books 
# Each user can give ratings
# All these things are saved in a file as JSON

